# Aegis – Grepolis Remaster

**Wersja:** 0.9.0  
**Co daje?** lżejszy, nowoczesny wygląd (fonty, tła, panele, przyciski), badge wersji, *welcome modal* oraz fajerwerki przy pierwszym uruchomieniu po aktualizacji.

## Instalacja (Tampermonkey)
1. Zainstaluj Tampermonkey (Chrome / Edge / Firefox).
2. Skrypt: \$RawBase/userscripts/grepolis-skin-switcher.user.js\

## Zrzuty (placeholdery – podmień w repo/assets):
- \ssets/bg/wave_tile.png\
- \ssets/ui/panel_bg.png\
- \ssets/branding/logo_aegis.png\

## Technicznie
- CSS ładowany z \$RawBase/assets/themes/classic/theme.css\
- Fajerwerki: Canvas + particles (lekko i bez bibliotek).
- Pierwsze uruchomienie liczone **per wersja** (klucz \Aegis::seen::<ver>\).

© Aegis / KID6767