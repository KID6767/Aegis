# Changelog

## 0.9.0
- Nowy theme CSS (font, panel, tło, przyciski z połyskiem).
- Badge wersji (prawy górny róg).
- Ekran powitalny + fajerwerki (pierwsze uruchomienie po update).
- Bez czerwieni w buildzie – try/catch, poprawne Base64.
