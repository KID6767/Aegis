
## 0.7.0-stable
- Full remaster with 4 themes (Classic, Pirate, Emerald, Dark)
- Dynamic theme switcher (dropdown)
- mapping.json centralized
- CSS per theme


## 0.8.0-dev
- Animacje (fale, glow, shine, mg�a)
- Panel ustawie� w UI
- Ukryte ficzery (odkryjesz w grze) ??


## 0.8.1-dev
- Real-time motywy (CSS+IMG), panel, ekran powitalny, badge wersji
- Assets + themes spi�te 1:1 (podmie� pliki w /assets i od�wie�)


## 0.8.1-dev
- Real-time motywy (CSS+IMG), panel, ekran powitalny, badge wersji
- Assets + themes spi�te 1:1 (podmie� pliki w /assets i od�wie�)


## 0.8.1-dev
- Real-time motywy (CSS+IMG), panel, ekran powitalny, badge wersji
- Assets + themes spi�te 1:1 (podmie� pliki w /assets i od�wie�)


## 0.8.1-dev
- Real-time motywy (CSS+IMG), panel, ekran powitalny, badge wersji
- Assets + themes spi�te 1:1 (podmie� pliki w /assets i od�wie�)

