﻿# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

**Wersja:** 0.8.1-dev  
**Motywy:** Classic, Pirate Epic, Emerald, Dark.  
**Instalacja (Tampermonkey):**  
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js
# Aegis – Grepolis Remaster

Wersja: 0.8.0-dev

Motywy: Classic, Pirate Epic, Emerald, Dark.

Instalacja (Tampermonkey):
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js

# Aegis – Grepolis Remaster

Wersja: 0.7.0-stable

Cztery motywy: Classic, Pirate Epic, Emerald, Dark.

Instalacja (Tampermonkey):
https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-skin-switcher.user.js















