# PowerShell installer for Aegis FULL 1.0.0
Write-Host 'Install Aegis...'
