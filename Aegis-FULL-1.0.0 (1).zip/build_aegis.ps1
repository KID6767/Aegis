# PowerShell build script for Aegis FULL 1.0.0
Write-Host 'Build Aegis...'
