## 1.0.0
- Pierwsze pełne wydanie
