// Full userscript Aegis 1.0.0 – panel powitalny, konfigurator, FX, themes
