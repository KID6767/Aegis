﻿<p align="center">
  <h1 style="color:#d4af37;background:#0a2e22;padding:10px;border-radius:12px;margin:0">
    Aegis – Grepolis Remaster
  </h1>
  <b style="color:#f2d574">Butelkowa zieleń + złoto • panel z logo • AssetMap • dym/fajerwerki</b><br/>
  <sub style="opacity:.8">Wersja 1.0.0</sub>
</p>

---

## Co to jest?
Aegis to stabilny remaster UI do Grepolis. Motywy, panel z logo, AssetMap, logger, animowany dym i fajerwerki na powitanie.

## Instalacja
1. Zainstaluj Tampermonkey.
2. Otwórz:
   https://raw.githubusercontent.com/KID6767/Aegis/main/userscripts/grepolis-aegis.user.js
3. Odśwież Grepolis – zobaczysz badge w prawym górnym rogu.
