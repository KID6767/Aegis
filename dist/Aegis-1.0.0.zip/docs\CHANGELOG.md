﻿# Dziennik zmian – Aegis

## 1.0.0
- Stabilny theme switcher (Classic/Remaster/Pirate/Dark).
- Panel z logo (Alt+G), przełącznik motywów (Alt+T).
- RAW Base + AssetMap (np. birema).
- FX: dym i fajerwerki (on/off).
- Logger (on/off), spójne logi.

## 0.9.x
- Wersje eksperymentalne: badge, dym, prosty powitalny.

## 0.8.x
- Reorganizacja repo (assets/themes, userscripts, docs).

## 0.7.x
- Wstępne style, animacje (glow/pulse).

## 0.6.x i starsze
- Prototypy minimalnego loadera.
