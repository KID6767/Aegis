# CHANGELOG

## 1.0.0
- Pierwsza pełna paczka: userscript (panel, badge, smoke, 4 motywy).
- AssetMap: logo + birema → podmiany z `assets/`.
- Baner SVG + dwa statki (zielony/piracki).
- Installery: BAT/PS1, ZIP + SHA256 + (opcjonalnie) git push.
