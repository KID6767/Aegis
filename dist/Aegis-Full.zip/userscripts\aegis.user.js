﻿// ==UserScript==
// @name        Aegis Grepolis Remaster
// @namespace   aegis
// @version     1.0.1
// @description SkĂłrki, panel, assetmap
// @match       *://*.grepolis.com/*
// @grant       none
// ==/UserScript==

(function() {
  console.log("Aegis loaded âś…");
  document.body.style.border = "5px solid limegreen";
})();
