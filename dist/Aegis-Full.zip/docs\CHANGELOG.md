﻿# Changelog

## 1.0.2
- Naprawa instalatora (here-stringi, brak interpolacji `${…}`),
- Panel (motywy, FX), dym i fajerwerki,
- AssetMap (branding), intercept IMG + MO,
- Welcome overlay + badge (light).

## 1.0.1
- Wersja wstępna.
