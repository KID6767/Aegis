# Dziennik zmian

## 0.9.0
- Nowy motyw CSS (czcionka, panel, tło, przyciski z połyskiem).
- Wersja odznaki (prawy górny róg).
- Ekran powitalny + fajerwerki (pierwsze uruchomienie po aktualizacji).
- 3 motywy: classic, pirate-epic, emerald (skrót Ctrl+Alt+T).
- Zaostrzone zabezpieczenia Base64 (walidacja + padding).

## 0.8.1
- Naprawione ścieżki assets.
- Obsługa błędów FromBase64String (try/catch + fallback).
- README/CHANGELOG generowane w buildzie.
- SHA-256 dla ZIP.

## 0.8.0
- Pierwszy stabilny build buildera.
- Userscript z loaderem CSS.
- Mapa zasobów (wstępna).