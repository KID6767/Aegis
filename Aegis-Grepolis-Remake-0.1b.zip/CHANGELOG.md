﻿# CHANGELOG

## [0.1b] - Initial beta
- userscript (Tampermonkey)
- welcome screen + theme switcher (Remaster / Pirate-Epic)
- placeholder assets
- mapping files
