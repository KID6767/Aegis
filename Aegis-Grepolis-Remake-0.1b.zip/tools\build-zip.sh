﻿#!/bin/sh
DIR=\/..
cd \"\\"
zip -r Aegis-Grepolis-Remake-0.1b.zip ./*
