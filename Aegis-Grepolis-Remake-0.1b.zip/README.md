﻿# Aegis â€” Grepolis Remake (0.1b - beta)

Quick start:
1. Unpack or place the contents of this folder into the root of your GitHub repo (userscripts/, config/, assets/, docs/, tools/).
2. Install Tampermonkey in your browser.
3. Install the userscript from userscripts/grepolis-skin-switcher.user.js (raw link from your repo).
4. Open Grepolis, log in, and you should see the Aegis switcher in the bottom-right corner.

Author: KID6767
License: MIT
