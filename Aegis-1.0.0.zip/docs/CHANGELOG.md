# Changelog

## 1.0.0
- Pierwsze stabilne wydanie Aegis Remaster.
- Motywy: Classic / Remaster / Pirate / Dark.
- Panel w prawym dolnym rogu (złota kostka).
- Badge wersji w prawym górnym rogu.
- Baner SVG (animacja + statki po bokach).
- Dym u dołu ekranu (subtelny).
- Fajerwerki na powitanie nowej wersji (jednorazowe).
- Userscript zgodny z Tampermonkey (`@run-at document-end`).
- Zero automatyzacji; kosmetyka i UX.
