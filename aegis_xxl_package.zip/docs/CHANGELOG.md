# Dziennik zmian – Aegis

## 1.0.0-xxl
- pełny userscript
- animowane jednostki
- build XXL
