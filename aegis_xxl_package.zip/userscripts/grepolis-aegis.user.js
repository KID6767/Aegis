// ==UserScript==
// @name         Aegis XXL
// @namespace    https://github.com/KID6767/Aegis
// @version      1.0.0-xxl
// @description  Pełny remaster UI z FX i animacjami
// @match        https://*.grepolis.com/*
// @match        https://*.grepolis.pl/*
// @run-at       document-end
// ==/UserScript==

(function(){
  console.log("Aegis XXL aktywny");
})();