# Changelog

## 1.0.0 XXL
- Release paczki XXL
